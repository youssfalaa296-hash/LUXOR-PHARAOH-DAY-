export function Bilingual({ ar, en, className = "" }: { ar: string; en: string; className?: string }) {
  return (
    <span className={className}>
      <span className="block" dir="rtl" lang="ar">{ar}</span>
      <span className="mt-0.5 block text-sm opacity-75" dir="ltr" lang="en">{en}</span>
    </span>
  );
}
