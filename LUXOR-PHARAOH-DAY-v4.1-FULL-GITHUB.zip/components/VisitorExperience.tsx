"use client";

import { useMemo, useState } from "react";
import {
  ArrowRight, Check, CheckCircle2, ChevronDown, Clock3, Compass, ExternalLink,
  Globe2, HelpCircle, MapPinned, MessageCircle, Navigation, Search, ShieldCheck,
  Sparkles, Star, Sun, WalletCards, X
} from "lucide-react";

const experiences = [
  { id: "east-bank", ar: "يوم آثار في الضفة الشرقية", en: "East Bank Heritage Day", category: "heritage", duration: 5, budget: "mid", descAr: "ابدأ بمعالم الأقصر الرئيسية ثم اترك مساحة للراحة والطعام.", descEn: "Start with Luxor's key heritage sights, with room for food and breaks." },
  { id: "west-bank", ar: "يوم الضفة الغربية", en: "West Bank Day", category: "heritage", duration: 6, budget: "mid", descAr: "مسار يركز على المقابر والمعابد والمناظر المفتوحة.", descEn: "A route focused on tombs, temples and open landscapes." },
  { id: "nile", ar: "تجربة على النيل", en: "Nile Experience", category: "nile", duration: 2, budget: "mid", descAr: "وقت هادئ على النيل مع نقطة انطلاق واضحة قبل الحجز.", descEn: "A relaxed Nile experience with a clear meeting point before booking." },
  { id: "sunset", ar: "غروب وتصوير", en: "Sunset & Photography", category: "photo", duration: 2, budget: "low", descAr: "اختيار مناسب لمن يريد وقتًا قصيرًا وإطلالات للتصوير.", descEn: "A short option for views, golden light and photography." },
  { id: "local", ar: "طعم الأقصر المحلي", en: "Local Luxor Taste", category: "food", duration: 2, budget: "low", descAr: "اكتشف خيارات الطعام المحلي مع مراجعة السعر والموقع قبل الذهاب.", descEn: "Explore local food options while checking price and location first." },
  { id: "short", ar: "تجربة سريعة", en: "Quick Luxor Experience", category: "quick", duration: 1, budget: "low", descAr: "لديك وقت قصير؟ اختر تجربة يمكن تنفيذها خلال ساعة تقريبًا.", descEn: "Short on time? Choose an option that fits roughly one hour." },
];

const categories = [
  ["all", "الكل", "All"], ["heritage", "آثار وفراعنة", "Heritage"], ["nile", "النيل", "Nile"],
  ["photo", "تصوير وغروب", "Photo & Sunset"], ["food", "أكل محلي", "Local Food"], ["quick", "وقت قصير", "Quick"],
] as const;

const checks = [
  ["source", "المصدر واضح", "Source is shown"], ["updated", "آخر تحديث ظاهر", "Last update is visible"],
  ["price", "نوع السعر واضح", "Price type is clear"], ["included", "ما يشمله السعر واضح", "Inclusions are clear"],
  ["meeting", "نقطة الالتقاء واضحة", "Meeting point is clear"], ["contact", "طريقة التواصل واضحة", "Contact path is clear"],
] as const;

function Bilingual({ ar, en, className = "" }: { ar: string; en: string; className?: string }) {
  return <span className={className}><span className="block" dir="rtl" lang="ar">{ar}</span><span className="mt-1 block text-sm opacity-70" dir="ltr" lang="en">{en}</span></span>;
}

function SectionHeading({ eyebrowAr, eyebrowEn, ar, en, id }: { eyebrowAr: string; eyebrowEn: string; ar: string; en: string; id?: string }) {
  return <div id={id} className="mb-7 scroll-mt-28">
    <div className="text-xs font-bold uppercase tracking-[.2em] text-amber-200/80">{eyebrowEn} · {eyebrowAr}</div>
    <h2 className="mt-3 text-3xl font-black md:text-5xl"><span dir="rtl" className="block">{ar}</span><span dir="ltr" className="mt-2 block text-stone-400">{en}</span></h2>
  </div>;
}

export function VisitorExperience() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [hours, setHours] = useState(4);
  const [budget, setBudget] = useState("mid");
  const [saved, setSaved] = useState<string[]>([]);
  const [openCheck, setOpenCheck] = useState(false);

  const filtered = useMemo(() => experiences.filter((x) => {
    const hay = `${x.ar} ${x.en} ${x.descAr} ${x.descEn}`.toLowerCase();
    return (category === "all" || x.category === category) && (!query || hay.includes(query.toLowerCase()));
  }), [query, category]);

  const plan = useMemo(() => experiences.filter((x) => x.duration <= hours && (budget === "any" || x.budget === budget)).slice(0, 3), [hours, budget]);

  function toggleSave(id: string) {
    setSaved((current) => current.includes(id) ? current.filter((x) => x !== id) : [...current, id]);
  }

  function sharePlan() {
    const names = plan.map((x) => `${x.en} / ${x.ar}`).join("\n");
    const text = `LUXOR PHARAOH DAY — My Luxor Plan\n${names}`;
    if (navigator.share) navigator.share({ title: "My Luxor Plan", text });
    else navigator.clipboard?.writeText(text);
  }

  return <main id="top" className="min-h-screen overflow-hidden">
    <header className="sticky top-0 z-40 border-b border-white/5 bg-[#090b10]/85 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3 md:px-8">
        <a href="#top" className="flex min-w-0 items-center gap-3" aria-label="LUXOR PHARAOH DAY Home">
          <img src="/logo.svg" alt="LUXOR PHARAOH DAY" className="h-10 w-auto" />
          <div className="hidden sm:block"><div className="text-[9px] tracking-[.2em] text-stone-500">YOUR PHARAOH DAY IN LUXOR</div><div className="text-[11px] text-stone-500" dir="rtl">يومك الفرعوني في الأقصر</div></div>
        </a>
        <nav className="hidden items-center gap-4 lg:flex" aria-label="Primary navigation">
          {[['الرئيسية','Home','#top'],['اكتشف','Discover','#discover'],['خطتي','My Day','#my-day'],['اتأكد','Check','#check'],['الوصول','Go','#go'],['المساعدة','Help','#help']].map(([ar,en,href]) => <a key={href} href={href} className="nav-link"><span dir="rtl">{ar}</span><span dir="ltr">{en}</span></a>)}
        </nav>
        <a href="#discover" className="rounded-full border border-amber-200/20 bg-amber-100/5 px-3 py-2 text-xs font-bold text-amber-100"><span dir="rtl">ابدأ</span> · Start</a>
      </div>
    </header>

    <section className="grid-bg relative mx-auto max-w-7xl px-5 pb-16 pt-14 md:px-8 md:pt-24">
      <div className="orb absolute left-1/2 top-10 h-80 w-80 -translate-x-1/2 rounded-full border border-amber-200/10" />
      <div className="relative grid gap-10 lg:grid-cols-[1.15fr_.85fr] lg:items-center">
        <div className="cinematic relative min-h-[280px] rounded-[2rem] lg:order-2 lg:min-h-[520px]"><img src="/images/luxor-dawn.svg" alt="Luxor dawn inspired cinematic landscape" loading="eager" /><div className="absolute bottom-5 left-5 right-5 z-10"><div className="text-xs font-bold uppercase tracking-[.2em] text-amber-200">LUXOR · EGYPT</div><div className="mt-1 text-2xl font-black">يومك الفرعوني في الأقصر</div><div className="text-sm text-stone-300">Your Pharaoh Day in Luxor.</div></div></div>
        <div>
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-amber-200/15 bg-amber-100/5 px-4 py-2 text-xs text-amber-100"><Sparkles size={14}/><Bilingual ar="منصة مستقلة لمساعدة زوار الأقصر" en="Independent Visitor Information & Local Concierge" /></div>
          <h1 className="text-5xl font-black leading-[.95] tracking-tight md:text-8xl"><span className="gold-text" dir="rtl">اعرف.</span><br/><span dir="rtl">اتأكد.</span><br/><span dir="rtl">اتحرك.</span></h1>
          <p className="mt-8 max-w-3xl text-lg leading-8 text-stone-300 md:text-xl"><span dir="rtl" className="block">اكتشف ما يناسب وقتك، راجع المعلومات المهمة قبل الاختيار أو الدفع، ثم تحرك بخطوة واضحة.</span><span dir="ltr" className="mt-2 block text-stone-500">Discover what fits your time, check important details before choosing or paying, then go with a clear next step.</span></p>
          <div className="mt-8 flex flex-wrap gap-3"><a href="#discover" className="rounded-full bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-300 px-6 py-3 font-black text-black shadow-xl shadow-amber-500/10">اكتشف الآن · Explore Now <ArrowRight className="ml-2 inline" size={17}/></a><a href="#my-day" className="glass rounded-full px-6 py-3 font-semibold">خطط يومك · Plan Your Day</a></div>
          <div className="mt-7 flex flex-wrap gap-2 text-xs text-stone-500"><span className="trust-pill"><ShieldCheck size={13}/> معلومات موثقة عند توفر التحقق</span><span className="trust-pill"><Clock3 size={13}/> تاريخ آخر تحديث ظاهر</span><span className="trust-pill"><Globe2 size={13}/> عربي + English</span></div>
        </div>
        <div className="glass rounded-[2rem] p-5 md:p-7">
          <div className="flex items-center justify-between"><Bilingual ar="ابدأ من احتياجك" en="Start With Your Need" className="text-xl font-black"/><Compass className="text-amber-200"/></div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            {[["الآن","What can I do now?","#discover"],["سعر","Check a price","#check"],["وصول","How do I get there?","#go"],["مساعدة","I need help","#help"]].map(([ar,en,href]) => <a href={href} key={en} className="rounded-2xl border border-white/7 bg-white/[.025] p-4 transition hover:-translate-y-0.5 hover:border-amber-200/25"><div dir="rtl" className="font-bold">{ar}</div><div dir="ltr" className="mt-1 text-sm text-stone-500">{en}</div></a>)}
          </div>
          <div className="mt-5 rounded-2xl border border-amber-200/10 bg-amber-100/[.03] p-4 text-sm leading-6 text-stone-400"><span dir="rtl">نحن لا نعرض معلومة على أنها مؤكدة إلا عندما يكون لديها أساس تحقق مناسب. المعلومات المتغيرة قد تحتاج إلى تأكيد مباشر قبل الدفع.</span><span dir="ltr" className="mt-1 block text-stone-600">Time-sensitive information may require direct confirmation before payment.</span></div>
        </div>
      </div>
    </section>

    <section id="discover" className="mx-auto max-w-7xl scroll-mt-28 px-5 py-12 md:px-8">
      <SectionHeading eyebrowAr="اكتشف" eyebrowEn="Discover" ar="اختر بناءً على وقتك واهتماماتك" en="Choose by time, interest and budget" />
      <div className="glass rounded-[2rem] p-5 md:p-7">
        <div className="grid gap-3 lg:grid-cols-[1.2fr_.8fr]">
          <label className="relative"><Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-500" size={18}/><input value={query} onChange={(e)=>setQuery(e.target.value)} className="field pl-11" placeholder="ابحث عن تجربة أو مكان · Search experiences" aria-label="Search experiences"/></label>
          <div className="flex gap-2 overflow-x-auto pb-1">{categories.map(([id,ar,en]) => <button key={id} onClick={()=>setCategory(id)} className={`shrink-0 rounded-full px-4 py-2 text-xs font-bold ${category===id ? 'bg-amber-200 text-black' : 'border border-white/8 bg-white/[.025] text-stone-300'}`}>{ar} · {en}</button>)}</div>
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((x) => <article key={x.id} className="card-hover rounded-3xl border border-white/7 bg-white/[.025] p-5">
            <div className="flex items-start justify-between gap-3"><div className="rounded-2xl bg-amber-100/8 p-3 text-amber-200"><Compass size={20}/></div><button onClick={()=>toggleSave(x.id)} aria-label={saved.includes(x.id)?'Remove from plan':'Save to plan'} className="rounded-full border border-white/8 p-2 text-stone-400 hover:text-amber-200">{saved.includes(x.id)?<Check size={17}/>:<Star size={17}/>}</button></div>
            <h3 className="mt-6 text-xl font-black" dir="rtl">{x.ar}</h3><p className="mt-1 text-sm text-amber-100/70" dir="ltr">{x.en}</p>
            <p className="mt-4 text-sm leading-6 text-stone-400" dir="rtl">{x.descAr}</p><p className="mt-1 text-xs leading-5 text-stone-600" dir="ltr">{x.descEn}</p>
            <div className="mt-5 flex flex-wrap gap-2 text-xs"><span className="meta-pill"><Clock3 size={13}/> {x.duration}h</span><span className="meta-pill">{x.budget==='low'?'اقتصادي · Low':'متوسط · Mid'}</span><span className="meta-pill">يحتاج تحقق · Check</span></div>
            <a href="#check" className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-amber-200">اتأكد قبل الحجز · Check first <ArrowRight size={15}/></a>
          </article>)}
        </div>
        {!filtered.length && <div className="rounded-3xl border border-white/7 p-8 text-center"><Search className="mx-auto text-stone-600"/><div className="mt-3 font-bold" dir="rtl">لم نجد نتائج</div><div className="mt-1 text-sm text-stone-500">No results found · Try different keywords.</div></div>}
      </div>
    </section>

    <section id="my-day" className="mx-auto max-w-7xl scroll-mt-28 px-5 py-12 md:px-8">
      <SectionHeading eyebrowAr="خطتي" eyebrowEn="My Day" ar="ابنِ يومك في دقائق" en="Build your Luxor day in minutes" />
      <div className="grid gap-5 lg:grid-cols-[.9fr_1.1fr]">
        <div className="glass rounded-[2rem] p-6 md:p-8">
          <Bilingual ar="كم من الوقت لديك؟" en="How much time do you have?" className="text-lg font-black"/>
          <div className="mt-5 grid grid-cols-4 gap-2">{[1,2,4,6].map(h=><button key={h} onClick={()=>setHours(h)} className={`rounded-2xl p-3 text-sm font-black ${hours===h?'bg-amber-200 text-black':'border border-white/8 text-stone-300'}`}>{h}h</button>)}</div>
          <div className="mt-7"><Bilingual ar="الميزانية" en="Budget" className="text-lg font-black"/><div className="mt-4 flex flex-wrap gap-2">{[['low','اقتصادي','Low'],['mid','متوسط','Mid'],['any','مرن','Any']].map(([id,ar,en])=><button key={id} onClick={()=>setBudget(id)} className={`rounded-full px-4 py-2 text-xs font-bold ${budget===id?'bg-amber-200 text-black':'border border-white/8 text-stone-300'}`}>{ar} · {en}</button>)}</div></div>
          <div className="mt-7 rounded-3xl border border-amber-200/10 bg-amber-100/[.03] p-5"><div className="flex gap-3"><Sun className="mt-1 text-amber-200" size={20}/><div><div className="font-bold" dir="rtl">الخطة إرشادية وليست حجزًا</div><div className="mt-1 text-xs text-stone-600" dir="ltr">Planning suggestions are not booking confirmations.</div></div></div></div>
          <button onClick={sharePlan} className="mt-5 w-full rounded-2xl border border-amber-200/20 bg-amber-100/5 px-5 py-3 font-bold text-amber-100">مشاركة خطتي · Share My Plan</button>
        </div>
        <div className="glass rounded-[2rem] p-6 md:p-8">
          <div className="flex items-center justify-between"><Bilingual ar={`خطة مقترحة لـ ${hours} ساعات`} en={`Suggested plan for ${hours} hours`} className="text-xl font-black"/><span className="rounded-full bg-amber-100/10 px-3 py-1 text-xs text-amber-100">{plan.length} خيارات</span></div>
          <div className="mt-6 space-y-3">{plan.map((x,i)=><div key={x.id} className="flex gap-4 rounded-2xl border border-white/7 bg-white/[.025] p-4"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-100/10 font-black text-amber-200">{i+1}</div><div className="min-w-0 flex-1"><div className="font-bold" dir="rtl">{x.ar}</div><div className="text-xs text-stone-500" dir="ltr">{x.en} · {x.duration}h</div></div><button onClick={()=>toggleSave(x.id)} className="text-stone-500 hover:text-amber-200" aria-label="Save experience">{saved.includes(x.id)?<Check size={18}/>:<Star size={18}/>}</button></div>)}{!plan.length && <div className="rounded-2xl border border-white/7 p-6 text-center text-sm text-stone-500">غيّر الوقت أو الميزانية · Adjust time or budget.</div>}</div>
        </div>
      </div>
    </section>

    <section id="check" className="mx-auto max-w-7xl scroll-mt-28 px-5 py-12 md:px-8">
      <SectionHeading eyebrowAr="اتأكد" eyebrowEn="Check" ar="لا تدفع قبل أن تعرف التفاصيل المهمة" en="Check the details before you pay" />
      <div className="grid gap-5 lg:grid-cols-[1fr_.9fr]">
        <div className="glass rounded-[2rem] p-6 md:p-8"><div className="grid gap-3 sm:grid-cols-2">{checks.map(([id,ar,en])=><button key={id} onClick={()=>setOpenCheck(openCheck===id?false:true)} className="rounded-2xl border border-white/7 bg-white/[.025] p-4 text-left transition hover:border-amber-200/20"><div className="flex items-center justify-between"><div><div dir="rtl" className="font-bold">{ar}</div><div dir="ltr" className="mt-1 text-xs text-stone-600">{en}</div></div>{openCheck===id?<ChevronDown size={16} className="text-amber-200"/>:<ShieldCheck size={16} className="text-stone-500"/>}</div>{openCheck===id&&<div className="mt-3 border-t border-white/5 pt-3 text-xs leading-5 text-stone-500" dir="rtl">تظهر هذه المعلومة بوضوح في بطاقة التجربة عندما تتوفر بيانات موثوقة. إذا كانت المعلومة متغيرة، راجع مقدم الخدمة قبل الدفع.</div>}</button>)}</div></div>
        <div className="glass rounded-[2rem] p-6 md:p-8"><Bilingual ar="حالة المعلومات" en="Information Status" className="text-xl font-black"/><div className="mt-5 space-y-3">{[["تم التحقق","Verified","emerald"],["معلومات مؤكدة","Confirmed","emerald"],["سعر تقديري","Estimated Price","amber"],["يحتاج إلى تأكيد","Needs Confirmation","amber"]].map(([ar,en,t])=><div key={en} className="flex items-center justify-between rounded-2xl border border-white/7 bg-white/[.025] p-4"><span><span dir="rtl" className="block font-bold">{ar}</span><span dir="ltr" className="block text-xs text-stone-600">{en}</span></span><span className={`status-${t}`}>{t==='emerald'?'✓':'!'}</span></div>)}</div></div>
      </div>
    </section>

    <section id="go" className="mx-auto max-w-7xl scroll-mt-28 px-5 py-12 md:px-8">
      <SectionHeading eyebrowAr="اتحرك" eyebrowEn="Go" ar="الوصول بدون تعقيد" en="Practical ways to get there" />
      <div className="grid gap-4 md:grid-cols-3">{[[Navigation,'اتجاهات الوصول','Directions','ابدأ من نقطة تجمع واضحة، وراجع الموقع قبل التحرك.'],[MapPinned,'أقرب نقطة وصول','Nearest Access Point','نوضح نقطة الوصول عندما تتوفر بيانات موثوقة.'],[Clock3,'وقت الرحلة','Estimated Travel Time','المدة تقديرية وقد تتغير حسب الزحام والوسيلة.']].map(([Icon,ar,en,desc])=><article key={en} className="glass rounded-3xl p-6"><Icon className="text-amber-200"/><h3 className="mt-5 text-xl font-black" dir="rtl">{ar}</h3><div className="mt-1 text-sm text-stone-500" dir="ltr">{en}</div><p className="mt-4 text-sm leading-6 text-stone-400" dir="rtl">{desc}</p></article>)}</div>
      <div className="mt-5 rounded-[2rem] border border-amber-200/10 bg-amber-100/[.03] p-6"><div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between"><Bilingual ar="الموقع لا يحتاج إذن الوصول إلا عندما تكون الميزة المطلوبة مرتبطة بموقعك." en="Location access is only needed when a feature actually depends on your location." className="text-sm font-bold"/><a href="#help" className="inline-flex shrink-0 items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-black text-black">المساعدة · Help <ArrowRight size={15}/></a></div></div>
    </section>

    <section id="before-buy" className="mx-auto max-w-7xl scroll-mt-28 px-5 py-12 md:px-8">
      <SectionHeading eyebrowAr="قبل أن تشتري" eyebrowEn="Before You Buy" ar="قائمة مراجعة بسيطة قبل أي دفع" en="A simple checklist before any payment" />
      <div className="glass rounded-[2rem] p-6 md:p-8"><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{['ماذا يشمل السعر؟ · What is included?','ماذا لا يشمل؟ · What is excluded?','مدة الخدمة · Duration','نقطة الالتقاء · Meeting point','سياسة الإلغاء · Cancellation','تحقق من السعر قبل الدفع · Check price before paying'].map((x)=><div key={x} className="flex items-center gap-3 rounded-2xl border border-white/7 bg-white/[.025] p-4"><CheckCircle2 className="shrink-0 text-amber-200" size={18}/><span className="text-sm font-bold">{x}</span></div>)}</div></div>
    </section>

    <section id="help" className="mx-auto max-w-7xl scroll-mt-28 px-5 py-12 md:px-8">
      <div className="glass rounded-[2rem] p-7 text-center md:p-10"><HelpCircle className="mx-auto text-amber-200" size={30}/><Bilingual ar="تحتاج إلى مساعدة؟" en="Need Help?" className="mt-4 block text-3xl font-black"/><p className="mx-auto mt-4 max-w-2xl text-stone-400"><span dir="rtl">إذا كانت لديك مشكلة في معلومة أو طلب أو دفع، تواصل معنا مع رقم الطلب إن وجد.</span><span dir="ltr" className="mt-1 block text-stone-600">For help with information, an order or payment, contact us with your order reference if available.</span></p><div className="mt-7 flex flex-wrap justify-center gap-3"><a href="https://wa.me/201012801568" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 font-black text-black"><MessageCircle size={18}/> WhatsApp · واتساب</a><a href="#payment" className="inline-flex items-center gap-2 rounded-full border border-white/10 px-6 py-3 font-bold">الدفع · Payment <ArrowRight size={16}/></a></div></div>
    </section>

    <footer className="mx-auto max-w-7xl px-5 pb-14 pt-8 text-center text-xs text-stone-600 md:px-8"><div dir="rtl">LUXOR PHARAOH DAY · منصة رقمية مستقلة لمعلومات الزوار والمساعدة المحلية في الأقصر</div><div dir="ltr" className="mt-1">Independent Digital Visitor Information & Local Concierge Platform</div><div className="mt-4 flex flex-wrap justify-center gap-4"><a href="#top">Privacy · الخصوصية</a><a href="#top">Terms · الشروط</a><a href="#top">Contact · التواصل</a></div><div className="mt-4">© {new Date().getFullYear()} LUXOR PHARAOH DAY</div></footer>
  </main>;
}
