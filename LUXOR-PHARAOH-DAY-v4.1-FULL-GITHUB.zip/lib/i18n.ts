import arCommon from "../locales/ar/common.json";
import enCommon from "../locales/en/common.json";
import arPayment from "../locales/ar/payment.json";
import enPayment from "../locales/en/payment.json";

export const translations = {
  ar: { common: arCommon, payment: arPayment },
  en: { common: enCommon, payment: enPayment }
} as const;

export type Locale = keyof typeof translations;

export function t(locale: Locale, section: "common" | "payment", key: string): string {
  const value = (translations[locale][section] as Record<string, string>)[key];
  return value ?? key;
}
