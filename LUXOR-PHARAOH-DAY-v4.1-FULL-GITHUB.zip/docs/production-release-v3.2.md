# LUXOR PHARAOH DAY v3.2 — Production+ Release

## Added
- Visitor-first discovery flow
- Search and category filters
- Time/budget day planner
- Save/share plan interactions
- Trust and verification status UI
- Before-you-buy checklist
- Transport guidance
- Help and contact flow
- Privacy and terms pages
- Structured content/operations model
- Compliance gate for regulated commercial functions

## Validation performed in build environment
- Required production files present
- JSON files parse successfully
- Package metadata validated
- Old LUXOR QUEST / LQ references removed
- Obvious secret patterns absent
- Payment review gate and PIN/OTP safety copy present

## External verification still required
The environment used to prepare this archive cannot resolve the public npm registry, so a real `npm install`, `npm ci`, TypeScript check and Next.js production build could not be executed here. Do not claim a successful production build until those commands pass in GitHub Actions, Vercel, or a machine with npm registry access.

## Required environment
- NEXT_PUBLIC_SITE_URL
- NEXT_PUBLIC_WHATSAPP_NUMBER=201012801568

## Commercial gate
Do not activate regulated selling/booking/organizing/collection features until the actual legal activity and licensing requirements are confirmed and the required official documents are in place.
