# GitHub → Vercel Execution Checklist

## GitHub
- [ ] Repository exists: `youssfalaa296-hash/luxor-pharaoh-day`
- [ ] ChatGPT/OpenAI GitHub integration is installed
- [ ] Repository access is explicitly enabled
- [ ] Repository appears in the integration's accessible repositories
- [ ] Source files pushed to `main`
- [ ] `package-lock.json` committed
- [ ] CI workflow present

## Local/CI
- [ ] Node 24+
- [ ] npm 11+
- [ ] `npm ci`
- [ ] `npm run preflight`
- [ ] `npm run typecheck`
- [ ] `npm run build`

## Vercel
- [ ] Repository imported
- [ ] Framework detected as Next.js
- [ ] Install = `npm ci`
- [ ] Build = `npm run build`
- [ ] Node 24 configured
- [ ] env vars configured for Production
- [ ] env vars configured for Preview as appropriate
- [ ] Preview deployed
- [ ] Browser QA passed
- [ ] Production deployed

## Domain
- [ ] domain registered/owned
- [ ] domain added to Vercel
- [ ] DNS configured
- [ ] HTTPS active
- [ ] `NEXT_PUBLIC_SITE_URL` updated
- [ ] canonical URL checked
- [ ] sitemap checked
- [ ] robots checked

## Operational
- [ ] data owner assigned
- [ ] source review process defined
- [ ] stale-data process defined
- [ ] issue reports reviewed manually
- [ ] payment review process defined
- [ ] support contact tested
- [ ] privacy/terms reviewed
