# LUXOR PHARAOH DAY — Production Settings v3.1

## Vercel
```text
Framework Preset: Next.js
Root Directory: .
Install Command: npm ci
Build Command: npm run build
Output Directory: Default
Development Command: npm run dev
Package Manager: npm
```

## GitHub Actions checks
```text
npm ci
npm run typecheck
npm run build
```

## Environment variables
```text
NEXT_PUBLIC_SITE_URL=<production site URL>
NEXT_PUBLIC_WHATSAPP_NUMBER=<WhatsApp number in international format>
```

Only create additional variables when the corresponding production service is actually configured.

## Deployment rule
A successful CI build confirms the code can install, type-check and build. It does not by itself confirm legal readiness, real-world data accuracy, provider verification, payment operations, backend persistence, domain configuration or final UX approval.
