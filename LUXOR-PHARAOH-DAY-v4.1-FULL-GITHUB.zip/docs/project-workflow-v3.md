# LUXOR PHARAOH DAY — Master Project Workflow v3.1

## 1. Identity
- Product: LUXOR PHARAOH DAY
- Arabic identity: يومك الفرعوني في الأقصر
- Tagline: Your Pharaoh Day in Luxor.
- Framework: Know. Check. Go. / اعرف • اتأكد • اتحرك
- Positioning: Independent Digital Visitor Information & Local Concierge Platform.

## 2. Product flow
1. Home
2. Discover
3. Know what is available
4. Check price/information status
5. Review source and last update
6. Review transport and access
7. Review Before You Buy
8. Contact / continue to the permitted provider flow
9. Manual Vodafone Cash payment when applicable
10. Payment review
11. Order confirmation
12. Go / experience

## 3. Trust model
Every important price or operational fact should have, where available:
- source
- last updated date
- verification status
- confirmed vs estimated distinction

Statuses:
- Verified / تم التحقق
- Confirmed Information / معلومات مؤكدة
- Estimated Price / سعر تقديري
- Needs Confirmation / يحتاج إلى تأكيد

## 4. Bilingual system
Locales:
- `locales/ar/`
- `locales/en/`

Important UI content is bilingual. Do not hardcode customer-facing translations in scattered components when a shared translation key is appropriate.

## 5. Payment
Current payment method: manual Vodafone Cash.
Payment number: `01012801568`.

Rules:
- No LINK integration.
- No card gateway in the current version.
- No payment API/webhook unless a real integration is later configured and verified.
- Payment proof submission is not automatic payment confirmation.
- Never request wallet PIN or OTP.
- Use order references such as `LPD-2026-XXXXXX`.

Suggested status flow:
`PENDING_PAYMENT → PAYMENT_SUBMITTED → PAYMENT_REVIEW → PAYMENT_CONFIRMED → ORDER_CONFIRMED`

Additional statuses may include rejected, cancelled, refund pending and refunded.

## 6. Technical stack
- Next.js
- React
- TypeScript
- Tailwind CSS
- npm
- GitHub
- Vercel

## 7. Local development
```bash
npm ci
npm run typecheck
npm run build
npm run dev
npm run start
```

`npm ci` requires a committed `package-lock.json`.

## 8. CI verification
GitHub Actions must:
1. checkout
2. setup Node 24
3. cache npm dependencies
4. validate `package-lock.json`
5. run `npm ci`
6. run `npm run typecheck`
7. run `npm run build`

Do not use `npx webpack`. Do not prefix commands with `sh`.

## 9. Vercel production settings
- Framework Preset: `Next.js`
- Root Directory: `.`
- Install Command: `npm ci`
- Build Command: `npm run build`
- Output Directory: `Default`
- Development Command: `npm run dev`
- Package Manager: `npm`

## 10. Environment variables
Current public configuration names:
- `NEXT_PUBLIC_SITE_URL`
- `NEXT_PUBLIC_WHATSAPP_NUMBER`

Secrets must never be committed. Add database/API/payment secrets only when a real backend integration exists.

## 11. Security
- No secrets in source control.
- Validate user input server-side when backend routes are introduced.
- Restrict admin access with real authentication and authorization.
- Do not expose private customer/payment proof data publicly.
- Minimize personal data collection.

## 12. Production gates
Before calling the service fully live, verify independently:
- domain and DNS
- HTTPS
- production build
- real backend/database if required
- real information sources
- provider verification process
- payment review process
- privacy/terms/cancellation policies
- admin access controls
- monitoring and backups
- Arabic RTL QA
- English LTR QA
- mobile and desktop QA

## 13. Brand/UX gate
The experience should feel premium and unmistakably Luxor/ancient-Egypt inspired while remaining modern and practical. Avoid fake official seals, fake verification marks, fabricated reviews, invented prices and unsupported claims.
