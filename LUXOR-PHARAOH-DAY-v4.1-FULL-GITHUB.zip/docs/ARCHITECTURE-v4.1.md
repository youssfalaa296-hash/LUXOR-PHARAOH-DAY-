# LUXOR PHARAOH DAY — ARCHITECTURE v4.1

## Layers
```text
Presentation
├─ app/
├─ components/
└─ public/

Domain / data contracts
├─ data/
├─ locales/
└─ lib/

Operational controls
├─ scripts/
├─ .github/workflows/
└─ vercel.json

Documentation
└─ docs/
```

## Target evolution
```text
Next.js Web/PWA
      ↓
Domain services / API layer
      ↓
Database + Storage
      ↓
Admin + Verification workflow
      ↓
Analytics / Notifications / Support
```

## Future database domains
- experiences
- places
- providers
- prices
- sources
- verification_events
- issue_reports
- plans
- orders
- payments
- users
- audit_logs

## Admin roles
Future role model should use least privilege, for example:
- owner
- administrator
- content_editor
- verifier
- support
- analyst

Exact permissions must be implemented before production admin access is enabled.

## Reliability rules
- Server-rendered content by default where practical.
- Client components only where interaction requires them.
- Avoid unnecessary browser-only APIs during initial render.
- Optimize images with Next.js image tooling when raster assets are introduced.
- Respect reduced-motion preferences.
- Keep critical visitor actions reachable within a small number of taps.
