# LUXOR PHARAOH DAY — v4.0 Production Architecture

## Release intent
A bilingual, mobile-first visitor information and local concierge platform for Luxor built around KNOW • CHECK • GO.

## v4 additions
- Cinematic Luxor visual hero with lightweight Ken Burns motion.
- PWA service worker shell for low-connection resilience.
- Reduced-motion support.
- Clear distinction between verified, confirmed, estimated and needs-confirmation information.
- Existing Vodafone Cash manual-review flow preserved without automatic payment confirmation.
- SEO, security headers, bilingual RTL/LTR foundations, error/404, sitemap, robots and deployment configuration preserved.

## Production gate
Do not label the release production-verified until a compatible Node/npm environment generates a real package-lock.json and successfully runs:

```text
npm ci
npm run preflight
npm run typecheck
npm run build
```

Then verify the deployed Vercel URL and the main visitor flows in a real browser.
