"use client";

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <main className="min-h-screen grid place-items-center px-6 text-center">
      <div className="glass max-w-xl rounded-3xl p-8">
        <div className="text-2xl font-black" dir="rtl">حدث خطأ غير متوقع</div>
        <div className="mt-2 text-stone-500" dir="ltr">Something went wrong.</div>
        <button onClick={() => reset()} className="mt-6 rounded-full bg-amber-200 px-6 py-3 font-black text-black">إعادة المحاولة · Try Again</button>
      </div>
    </main>
  );
}
