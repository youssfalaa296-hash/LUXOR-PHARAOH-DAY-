import { PaymentPanel } from "../../components/PaymentPanel";
export default function PaymentPage(){return <main className="min-h-screen pt-8"><PaymentPanel/></main>}
