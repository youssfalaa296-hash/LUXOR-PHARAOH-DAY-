export default function NotFound() {
  return <main className="min-h-screen grid place-items-center px-6 text-center"><div><div className="text-7xl font-black text-amber-200">404</div><div className="mt-3 text-2xl font-black" dir="rtl">الصفحة غير موجودة</div><div className="mt-1 text-stone-500">Page Not Found</div><a href="/" className="mt-6 inline-block rounded-full bg-amber-200 px-6 py-3 font-black text-black">الرئيسية · Home</a></div></main>;
}
