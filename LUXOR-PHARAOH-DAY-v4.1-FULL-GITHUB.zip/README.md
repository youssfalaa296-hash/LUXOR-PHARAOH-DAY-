# LUXOR PHARAOH DAY 🏺👑

**Your Pharaoh Day in Luxor · يومك الفرعوني في الأقصر**

Independent bilingual digital visitor information & local concierge platform.

## KNOW • CHECK • GO
- **KNOW:** discover experiences by time, interest and budget.
- **CHECK:** see source, last update, verification status and price type.
- **GO:** understand practical transport and next steps.

## Production+ additions
- mobile-first premium UI
- discovery search and category filters
- time/budget day planner
- save/share plan in the browser
- trust/status model
- before-you-buy checklist
- transport guidance section
- help/contact flow
- privacy and terms pages
- structured operational data model for future admin/database
- manual Vodafone Cash review flow; no PIN/OTP collection

## Run

```bash
npm install
npm run preflight
npm run typecheck
npm run build
npm run dev
```

Required environment variables are documented in `.env.example`.

## Compliance gate
The UI does not claim government affiliation, licensing, confirmed prices, verified providers, or confirmed payments without a real basis. Regulated commercial functions must remain disabled until the actual legal activity and licensing requirements are confirmed.

## v4.1 technical documentation
- `docs/TECHNICAL_MASTER_RUNBOOK-v4.1.md` — complete build, install, GitHub, Vercel, domain, QA, security, privacy, legal and release workflow.
- `docs/ARCHITECTURE-v4.1.md` — application architecture and future production evolution.
- `docs/GITHUB-VERCEL-EXECUTION-CHECKLIST-v4.1.md` — execution checklist from repository to production.
- `docs/PROJECT-STATUS-v4.1.md` — explicit completed/not-completed gates.
